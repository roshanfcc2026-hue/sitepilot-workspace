"use client";
import {useEffect,useRef,useState} from "react";
import {Check,Copy,MessageSquareText} from "lucide-react";
import {overallSummary} from "@/lib/summary";
import type {Audit} from "@/lib/types";

export default function OverallSummary({audit}:{audit:Audit}) {
  const {text,ready} = overallSummary(audit);
  const [copied,setCopied] = useState(false), [copyError,setCopyError] = useState(false);
  const paragraph = useRef<HTMLParagraphElement>(null);
  useEffect(()=>{setCopied(false);setCopyError(false);},[text]);
  useEffect(()=>{if(!copied)return;const timer=setTimeout(()=>setCopied(false),3000);return()=>clearTimeout(timer);},[copied]);
  async function copy(){
    try{await navigator.clipboard.writeText(text);setCopied(true);setCopyError(false);}
    catch{setCopyError(true);if(paragraph.current){const range=document.createRange();range.selectNodeContents(paragraph.current);const selection=window.getSelection();selection?.removeAllRanges();selection?.addRange(range);}}
  }
  return <section className="overall-summary" aria-labelledby="overall-summary-title">
    <div className="overall-summary-heading"><div><MessageSquareText size={20}/><h2 id="overall-summary-title">Overall summary</h2></div>
      <button className="button secondary" disabled={!ready} onClick={copy}>{copied?<Check size={15}/>:<Copy size={15}/>} {copied?"Copied":"Copy summary"}</button>
    </div>
    <p className="overall-summary-message" ref={paragraph}>{text}</p>
    <p className="overall-summary-note" role="status">{copyError?"Copy wasn’t available. The paragraph is selected so you can copy it manually.":copied?"Summary copied. Paste it into your email or message.":ready?"A short message based on this saved review. Copy it into an email or message.":"Summary pending · waiting for completed checks"}</p>
  </section>;
}
