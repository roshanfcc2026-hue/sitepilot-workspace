"use client";
import {useEffect,useRef,useState} from "react";
import {CheckCircle2,Clock3,Loader2,Pause,Play,RotateCcw,TriangleAlert} from "lucide-react";
import type {AuditJob} from "@/lib/types";

export default function AuditQueue({jobs,request,refresh,poll,onError}:{jobs:AuditJob[];request:(path:string,body?:unknown)=>Promise<any>;refresh:()=>Promise<unknown>;poll:()=>Promise<unknown>;onError:(message:string)=>void}){
  const [paused,setPaused]=useState(false);const inFlight=useRef(new Set<string>());const [expanded,setExpanded]=useState(false);
  const pending=jobs.filter(j=>j.status==="queued"||j.status==="running");const failed=jobs.filter(j=>j.status==="failed");
  useEffect(()=>{if(!pending.length)return;const timer=setInterval(()=>void poll(),5000);return()=>clearInterval(timer);},[pending.length,poll]);
  useEffect(()=>{
    if(paused)return;
    const ready=jobs.filter(j=>j.status==="queued"||(j.status==="running"&&(j.leaseUntil||0)<Date.now())).sort((a,b)=>Number(a.type==="speed")-Number(b.type==="speed")||a.createdAt.localeCompare(b.createdAt));
    for(const job of ready){if(inFlight.current.has(job.id))continue;if(inFlight.current.size>=2)break;if(job.type==="speed"&&inFlight.current.size)break;
      inFlight.current.add(job.id);
      void request("/api/jobs",{action:"run",id:job.id}).catch(e=>{setPaused(true);onError(`${e.message} Your saved queue is safe. Resume after reconnecting.`);}).finally(async()=>{inFlight.current.delete(job.id);await refresh();});
      if(job.type==="speed")break;
    }
  },[jobs,paused,request,refresh,onError]);
  if(!pending.length&&!failed.length&&!jobs.some(j=>j.warnings?.length))return null;
  const visible=[...pending,...failed,...jobs.filter(j=>j.warnings?.length)];
  return <section className="panel queue-panel" aria-label="Saved audit queue"><div className="queue-heading"><span className="round-icon lime">{pending.length&&!paused?<Loader2 className="spin" size={20}/>:<CheckCircle2 size={20}/>}</span><div><h2>{pending.length?`${pending.length} saved check${pending.length===1?"":"s"} ${paused?"paused":"in your queue"}`:"Reports saved · some checks need attention"}</h2><p>Reports save before speed tests. Progress survives reloads; queued work resumes when you return.</p></div><div className="button-group">{pending.length>0&&<button className="button secondary" onClick={()=>setPaused(!paused)}>{paused?<Play size={14}/>:<Pause size={14}/>} {paused?"Resume":"Pause in this tab"}</button>}<button className="button secondary" onClick={()=>setExpanded(!expanded)}>{expanded?"Hide details":"View progress"}{failed.length?` · ${failed.length} need retry`:""}</button></div></div>{expanded&&<div className="queue-items">{visible.map(j=><div className="queue-item" key={j.id}><span>{j.status==="failed"?<TriangleAlert size={16}/>:j.status==="running"?<Loader2 size={16} className="spin"/>:<Clock3 size={16}/>}</span><div><strong>{j.company}</strong><small>{j.type==="audit"?"Website evidence":"Speed tests"} · {j.status}{j.error?` · ${j.error}`:""}{j.warnings?.length?` · ${j.warnings.join(" ")}`:""}</small></div>{j.status==="failed"&&<button className="button secondary" onClick={async()=>{try{await request("/api/jobs",{action:"retry",id:j.id});setPaused(false);await refresh();}catch(e){onError((e as Error).message);}}}><RotateCcw size={14}/> Retry</button>}</div>)}<p className="fine-print">Up to two website checks run at once. Closing every workspace tab pauses new work; interrupted checks can recover after a five-minute lease.</p></div>}</section>;
}
