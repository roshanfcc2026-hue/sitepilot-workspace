import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
import {DatabaseSync} from 'node:sqlite';
import {pathToFileURL} from 'node:url';

const folder='.sites-runtime/persistence-tests';fs.mkdirSync(folder,{recursive:true});
const database=new DatabaseSync(':memory:');database.exec(fs.readFileSync('drizzle/0000_tense_black_bird.sql','utf8'));
const adapter={prepare(sql){let values=[];return {bind(...args){values=args;return this;},async first(){return database.prepare(sql).get(...values)||null;},async all(){return {results:database.prepare(sql).all(...values)};},async run(){const result=database.prepare(sql).run(...values);return {meta:{changes:Number(result.changes)}};}};},async batch(statements){database.exec('BEGIN');try{const result=[];for(const statement of statements)result.push(await statement.run());database.exec('COMMIT');return result;}catch(e){database.exec('ROLLBACK');throw e;}}};
globalThis.__sitepilotTestEnv={DB:adapter};
for(const name of ['types','content','audit','queue-model','store','jobs','research-import','outreach-model','outreach']){
  let source=fs.readFileSync(`lib/${name}.ts`,'utf8').replace(/from "\.\/([\w-]+)"/g,'from "./$1.mjs"');
  source=source.replace(/import \{\s*env\s*\} from "cloudflare:workers";/,'const env = globalThis.__sitepilotTestEnv;');
  source=source.replace('import { getChatGPTUser } from "@/app/chatgpt-auth";','const getChatGPTUser = async()=>globalThis.__sitepilotTestUser;');
  source=source.replace('import research from "./data/construction-research.json";',`const research = ${fs.readFileSync('lib/data/construction-research.json','utf8')};`);
  fs.writeFileSync(`${folder}/${name}.mjs`,ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);
}
const load=name=>import(pathToFileURL(`${process.cwd()}/${folder}/${name}.mjs`));
const store=await load('store');const jobs=await load('jobs');const {importResearch}=await load('research-import');const {recordId,websiteKey}=await load('queue-model');
const originalFetch=globalThis.fetch;let speedRequests=0;let failWebsite=false;
globalThis.fetch=async(input)=>{const url=String(input);if(url.includes('cloudflare-dns.com'))return Response.json({Answer:[{type:1,data:'93.184.216.34'}]});if(url.includes('googleapis.com')){speedRequests++;return new Response('{}',{status:429});}if(url.endsWith('/robots.txt'))return new Response('User-agent: *\nAllow: /',{headers:{'content-type':'text/plain'}});if(failWebsite)throw new Error('Network interrupted');return new Response('<html lang="en"><head><title>Local builder</title><meta name="viewport" content="width=device-width"></head><body><h1>Local construction</h1><p>We build homes and remodel kitchens for homeowners in our local service area. Please contact our team to discuss the next project and arrange an initial visit.</p></body></html>',{headers:{'content-type':'text/html'}});};
test.after(()=>{globalThis.fetch=originalFetch;database.close();});

test('anonymous access is rejected and owner-scoped ids cannot collide',async()=>{await assert.rejects(store.owner(),/AUTH_REQUIRED/);assert.notEqual(await recordId('audit','a','same'),await recordId('audit','b','same'));assert.equal(websiteKey('HTTP://www.Example.com/'),websiteKey('https://example.com'));});
test('research imports atomically once and preserves edited drafts',{skip:JSON.parse(fs.readFileSync('lib/data/construction-research.json','utf8')).length===0},async()=>{
  const first=await importResearch('import-owner');assert.equal(first.count,10);assert.equal((await store.list('import-owner','audit')).length,10);assert.equal((await store.list('import-owner','campaign')).length,7);assert.equal((await store.list('import-owner','article')).length,10);
  const draft=(await store.list('import-owner','campaign'))[0];draft.messages[0].body='Owner edited this draft';await store.put('import-owner','campaign',draft);
  await importResearch('import-owner');assert.equal((await store.list('import-owner','audit')).length,10);assert.equal((await store.get('import-owner',draft.id,'campaign')).messages[0].body,'Owner edited this draft');assert.equal((await store.list('other-owner','audit')).length,0);
});
test('batch persists placeholders before work and skips equivalent URLs',async()=>{
  const r=await jobs.queueWebsites('queue-owner',{urls:['https://example.com/','http://www.example.com','https://another-business.com/']});assert.deepEqual(r,{added:2,skipped:1});const saved=await store.list('queue-owner','audit');assert.equal(saved.length,2);assert.ok(saved.every(a=>a.pages.length===0&&a.auditState==='queued'));await jobs.queueWebsites('queue-owner',{urls:['example.com']});assert.equal((await store.list('queue-owner','audit')).length,2);
  await assert.rejects(jobs.queueWebsites('invalid-owner',{urls:['https://example.com','http://127.0.0.1']}));assert.equal((await store.list('invalid-owner','audit')).length,0);
});
test('foreign owners cannot run or retry another owner’s queued work',async()=>{const job=(await store.list('queue-owner','job'))[0];await assert.rejects(jobs.runJob('stranger',job.id),/not found/);await assert.rejects(jobs.retryJob('stranger',job.id),/not found/);});
test('competing runners claim once; HTML saves before speed failures',async()=>{
  const job=(await store.list('queue-owner','job'))[0];const result=await Promise.all([jobs.runJob('queue-owner',job.id),jobs.runJob('queue-owner',job.id)]);assert.equal(result.filter(r=>r.claimed).length,1);
  const saved=await store.get('queue-owner',job.auditId,'audit');assert.equal(saved.auditState,'complete');assert.equal(saved.pages.length,1);assert.equal(saved.metrics.length,0);assert.equal(speedRequests,0);
  const speed=(await store.list('queue-owner','job')).find(j=>j.type==='speed');await jobs.runJob('queue-owner',speed.id);const after=await store.get('queue-owner',job.auditId,'audit');assert.equal(after.pages.length,1);assert.equal(after.metrics[0].status,'unavailable');assert.equal(after.metrics.length,2);assert.equal(speedRequests,1);await assert.rejects(jobs.queueSpeed('queue-owner',job.auditId),/cooling down/);
});
test('failed work remains saved and retry completes without duplicated outputs',async()=>{
  const job=(await store.list('queue-owner','job')).find(j=>j.type==='audit'&&j.status==='queued');failWebsite=true;await jobs.runJob('queue-owner',job.id);assert.equal((await store.get('queue-owner',job.id,'job')).status,'failed');assert.ok(await store.get('queue-owner',job.auditId,'audit'));failWebsite=false;await jobs.retryJob('queue-owner',job.id);await jobs.runJob('queue-owner',job.id);assert.equal((await store.get('queue-owner',job.id,'job')).status,'complete');const count=(await store.list('queue-owner','campaign')).length;
  await jobs.queueWebsites('queue-owner',{reauditId:job.auditId});await jobs.runJob('queue-owner',job.id);assert.equal((await store.list('queue-owner','campaign')).length,count);
});
test('an interrupted run can recover after its saved lease expires',async()=>{
  await jobs.queueWebsites('recover-owner',{urls:['https://example.com']});let job=(await store.list('recover-owner','job'))[0];await store.put('recover-owner','job',{...job,status:'running',leaseToken:'old-tab',leaseUntil:Date.now()-1});await jobs.runJob('recover-owner',job.id);assert.equal((await store.get('recover-owner',job.id,'job')).status,'complete');assert.equal((await store.get('recover-owner',job.auditId,'audit')).pages.length,1);
});

const outreach=await load('outreach');const model=await load('outreach-model');
let crmContact;const crmOwner='crm-owner';
test('contacts persist with strict owner boundaries and duplicate protection',async()=>{
 await jobs.queueWebsites(crmOwner,{urls:['https://example.com']});const audit=(await store.list(crmOwner,'audit'))[0];
 crmContact=await outreach.saveContact(crmOwner,{auditId:audit.id,name:'Jamie',email:'jamie@example.com',stage:'Auto',followUp:'2026-10-12',nextStep:'Discuss the review'});
 assert.equal((await outreach.outreachData(crmOwner)).contacts[0].name,'Jamie');assert.equal((await outreach.outreachData('stranger')).contacts.length,0);
 await assert.rejects(outreach.saveContact('stranger',{...crmContact}),/website/);
 await assert.rejects(outreach.saveContact(crmOwner,{...crmContact,id:'',email:'JAMIE@example.com'}),/already saved/);
 await assert.rejects(outreach.saveContact(crmOwner,{...crmContact,followUp:'2026-02-31'}),/valid date/);
 await assert.rejects(outreach.saveContact(crmOwner,{...crmContact,updatedAt:'outdated'}),/another tab/);
});
test('logging is idempotent, recoverable and does not count campaign drafts',async()=>{
 const audits=await store.list(crmOwner,'audit');const data=await outreach.outreachData(crmOwner);assert.equal(model.outreachStats(audits,data.contacts,data.activities).contacted,0);
 const input={contactId:crmContact.id,type:'Message sent',channel:'Email',date:'2026-10-12',note:'Website review',requestId:'test-message-0001'};
 const a=await outreach.logActivity(crmOwner,input);await outreach.logActivity(crmOwner,input);await outreach.logActivity(crmOwner,{...input,requestId:'test-message-0002'});
 await outreach.logActivity(crmOwner,{...input,type:'Reply received',requestId:'test-reply-00001'});
 let d=await outreach.outreachData(crmOwner);let stats=model.outreachStats(audits,d.contacts,d.activities,'2026-10-13');assert.equal(stats.messages,2);assert.equal(stats.contacted,1);assert.equal(stats.replied,1);assert.equal(stats.responseRate,100);assert.equal(stats.followUps,1);
 await outreach.setActivityRemoved(crmOwner,a.id,true);d=await outreach.outreachData(crmOwner);assert.equal(model.outreachStats(audits,d.contacts,d.activities).messages,1);
 await outreach.setActivityRemoved(crmOwner,a.id,false);d=await outreach.outreachData(crmOwner);assert.equal(model.outreachStats(audits,d.contacts,d.activities).messages,2);
 await assert.rejects(outreach.logActivity('stranger',input),/not found/);await assert.rejects(outreach.setActivityRemoved('stranger',a.id,true),/not found/);
});
test('work counts websites once and keeps individual people separate',async()=>{
 const second=await outreach.saveContact(crmOwner,{auditId:crmContact.auditId,name:'Alex',email:'alex@example.com',stage:'In progress'});
 await outreach.logActivity(crmOwner,{contactId:crmContact.id,type:'Work started',channel:'Other',date:'2026-10-12',note:'Kickoff',requestId:'test-work-00001'});
 const d=await outreach.outreachData(crmOwner);const stats=model.outreachStats(await store.list(crmOwner,'audit'),d.contacts,d.activities);assert.equal(stats.people,2);assert.equal(stats.worked,1);assert.equal(stats.won,1);assert.equal(model.matchesFilter(crmContact,d.activities,'Clients'),true);assert.equal(model.displayStage(crmContact,model.activeHistory(crmContact,d.activities)),'In progress');assert.equal(model.followUpDue({...second,followUp:'2026-10-12',stage:'Do not contact'},'2026-10-13'),false);
});
test('do not contact is enforced and inbound-only replies do not inflate reply rate',async()=>{
 const c=await outreach.saveContact(crmOwner,{...crmContact,stage:'Do not contact'});
 await assert.rejects(outreach.logActivity(crmOwner,{contactId:c.id,type:'Message sent',channel:'Email',date:'2026-10-12',requestId:'blocked-test-001'}),/Do not contact/);
 const other={...c,id:'other',stage:'Auto'};const history=[{id:'inbound',contactId:other.id,type:'Reply received',date:'2026-10-12',createdAt:'2026-10-12',removed:false}];
 const stats=model.outreachStats([], [other],history);assert.equal(stats.contacted,0);assert.equal(stats.replied,1);assert.equal(stats.responseRate,null);
});
