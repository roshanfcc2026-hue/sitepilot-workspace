import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
import {pathToFileURL} from 'node:url';
fs.mkdirSync('.sites-runtime/test-modules',{recursive:true});
for(const name of ['types','content','audit','summary','report']){
  let source=fs.readFileSync(`lib/${name}.ts`,'utf8');
  source=source.replaceAll('"./content"','"./content.mjs"').replaceAll('"./types"','"./types.mjs"').replaceAll('"./summary"','"./summary.mjs"');
  fs.writeFileSync(`.sites-runtime/test-modules/${name}.mjs`,ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);
}
const {publicUrl,analyzeHtml,pageSpeed}=await import(pathToFileURL(`${process.cwd()}/.sites-runtime/test-modules/audit.mjs`));
const {scoreFindings,createCampaign,createBrief,csvCell}=await import(pathToFileURL(`${process.cwd()}/.sites-runtime/test-modules/content.mjs`));
const {defaultSettings}=await import(pathToFileURL(`${process.cwd()}/.sites-runtime/test-modules/types.mjs`));
const {reportHtml}=await import(pathToFileURL(`${process.cwd()}/.sites-runtime/test-modules/report.mjs`));
const {overallSummary}=await import(pathToFileURL(`${process.cwd()}/.sites-runtime/test-modules/summary.mjs`));
const url='https://example.com/';
test('rejects private targets, credentials, schemes, numeric encodings and ports',()=>{
 for(const bad of ['http://localhost','http://127.0.0.1','http://2130706433','http://0x7f000001','http://[::1]','http://10.0.0.1','http://host.internal','https://user:pass@example.com','file:///etc/passwd','https://example.com:8080'])assert.throws(()=>publicUrl(bad));
 assert.equal(publicUrl('example.com').href,url);
});
test('does not mistake commented or script-string metadata for real elements',()=>{
 const {findings}=analyzeHtml('<html><!-- <title>False</title> --><script>var x="<meta name=description content=fake>";</script><body><h1>Real</h1><img src="photo.jpg"></body></html>',url,150,90);
 assert.equal(findings.find(f=>f.title==='Descriptive page title').status,'issue');
 assert.equal(findings.find(f=>f.title==='Meta description').status,'issue');
 assert.equal(findings.find(f=>f.title==='Main heading').status,'pass');
 assert.equal(findings.find(f=>f.title==='Image text alternatives').status,'issue');
 assert.equal(findings.find(f=>f.title==='Reserved image space').status,'review');
});
test('empty alt is valid for decorative images; zoom and noindex are surfaced',()=>{
 const {findings}=analyzeHtml('<html lang="en"><title>Sample &amp; Co</title><meta name="description" content="A useful summary"><meta name="viewport" content="width=device-width, user-scalable=no"><meta name="robots" content="noindex"><h1>Hello</h1><img src="decoration.svg" alt="" width="10" height="10"></html>',url,300,80);
 assert.equal(findings.find(f=>f.title==='Image text alternatives').status,'pass');
 assert.equal(findings.find(f=>f.title==='Pinch zoom').status,'issue');
 assert.match(findings.find(f=>f.title==='Indexing directive').evidence,/noindex/);
 assert.equal(findings.find(f=>f.title==='Page language').status,'pass');
});

test('JavaScript shells require rendered review before outreach claims',()=>{
 const {findings}=analyzeHtml('<html><head><script src="/app.js"></script></head><body><div id="app"></div></body></html>',url,120,70);
 for(const title of ['Main heading','Descriptive page title','Meta description']){const f=findings.find(x=>x.title===title);assert.equal(f.status,'review');assert.equal(f.confidence,'Needs review');}
});
test('unmeasured checks do not inflate or depress the score',()=>{
 assert.equal(scoreFindings([{status:'review',severity:'high'}]),null);
 assert.equal(scoreFindings([{status:'pass',severity:'high'},{status:'review',severity:'high'}]),100);
 assert.equal(scoreFindings([{status:'pass',severity:'medium'},{status:'issue',severity:'medium'}]),50);
});
test('campaigns use verified issues and source evidence, never speculative design findings',()=>{
 const parsed=analyzeHtml('<html><body><h1>Business</h1></body></html>',url,100,90);
 const audit={id:'audit',url,company:'Acme',contact:'Jamie',email:'',industry:'architecture',createdAt:'2026-10-12T00:00:00Z',pages:[parsed.page],findings:parsed.findings};
 const campaign=createCampaign(audit,{...defaultSettings,sender:'Alex',agency:'Studio'});
 assert.equal(campaign.messages.length,3);assert.match(campaign.messages[0].body,/Hi Jamie/);assert.match(campaign.messages[0].body,/No non-empty title/);assert.doesNotMatch(campaign.messages[0].body,/Visual hierarchy/);
 assert.throws(()=>createCampaign({...audit,findings:parsed.findings.filter(f=>f.status!=='issue')},defaultSettings));
 const brief=createBrief(audit,'architecture studio guide');assert.equal(brief.status,'Brief');assert.match(brief.body,/not a finished blog/);assert.match(brief.body,/https:\/\/example.com/);
});
test('unavailable PageSpeed tests never fabricate metrics',async()=>{
 const original=globalThis.fetch;globalThis.fetch=async()=>new Response('{}',{status:429});
 try{const result=await pageSpeed(url,'mobile');assert.equal(result.metric.status,'unavailable');assert.equal(result.metric.performance,undefined);assert.equal(result.findings.length,0);assert.match(result.metric.reason,/quota/);}finally{globalThis.fetch=original;}
});
test('CSV exports neutralize spreadsheet formulas and preserve quoting',()=>{
 assert.equal(csvCell('=HYPERLINK("evil")'),'"\'=HYPERLINK(""evil"")"');assert.equal(csvCell('hello, world'),'"hello, world"');assert.equal(csvCell('line\nnext'),'"line\nnext"');
});
test('printable reports escape scraped HTML and company names',()=>{
 const html=reportHtml({company:'<script>alert(1)</script>',url:'https://example.com/',createdAt:'2026-10-12',pages:[],findings:[],metrics:[],limitations:['<img src=x onerror=alert(1)>'],score:null},'Agency');
 assert.doesNotMatch(html,/<script>/);assert.match(html,/&lt;script&gt;/);assert.doesNotMatch(html,/<img src=x/);
});

test('summaries use personalized research while keeping its original review date',{skip:JSON.parse(fs.readFileSync('lib/data/construction-research.json','utf8')).length===0},()=>{
 const audits=JSON.parse(fs.readFileSync('lib/data/construction-research.json','utf8'));
 for(const audit of audits){const summary=overallSummary(audit);assert.equal(summary.ready,true);assert.ok(summary.text.includes(audit.company));assert.ok(summary.text.includes(audit.research.feedback));assert.match(summary.text,/October 12, 2026/);assert.ok(reportHtml(audit,'Agency').includes('Overall summary'));}
});

test('summary groups repeated issues, excludes uncertain claims and refreshes past old research',()=>{
 const {page,findings}=analyzeHtml('<html><h1>Welcome</h1></html>',url,100,90);
 const audit={company:'Sample Builder',createdAt:'2026-10-13',pages:[page,page],findings:[...findings,...findings,{title:'Speculative speed claim',status:'issue',confidence:'Needs review',severity:'high'}],research:{reviewedAt:'2026-10-12',feedback:'Old visual claim'}};
 const summary=overallSummary(audit).text;
 assert.match(summary,/October 13, 2026/);assert.match(summary,/2 pages sampled/);
 assert.equal(summary.match(/missing page titles/g).length,1);assert.doesNotMatch(summary,/Speculative|Old visual|Visual hierarchy|Small-screen layout/);
});

test('summaries explain pending and failed checks without creating outreach claims',()=>{
 const audit={company:'Builder',createdAt:'2026-10-13',pages:[],findings:[]};
 assert.equal(overallSummary(audit).ready,false);assert.match(overallSummary(audit).text,/once the checks finish/);
 assert.match(overallSummary({...audit,auditState:'failed'}).text,/Retry the audit/);
});

test('a clean sample is not described as a perfect website',()=>{
 const audit={company:'Builder',createdAt:'2026-10-13',pages:[{url}],findings:[{status:'review',title:'Visual hierarchy & layout'}]};
 const result=overallSummary(audit);assert.equal(result.ready,true);assert.match(result.text,/no verified issues in the checks completed/);assert.match(result.text,/closer review/);assert.doesNotMatch(result.text,/perfect|100|poor|slow/);
});
