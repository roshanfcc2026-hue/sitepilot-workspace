import { sqliteTable, text, index } from "drizzle-orm/sqlite-core";
export const records = sqliteTable("records", {
  id: text("id").primaryKey(),
  owner: text("owner").notNull(),
  kind: text("kind").notNull(),
  data: text("data").notNull(),
  updated: text("updated").notNull(),
},table=>[index("records_owner_kind_updated").on(table.owner,table.kind,table.updated)]);
