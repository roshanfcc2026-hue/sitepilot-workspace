export type Category = "SEO" | "Mobile" | "Performance" | "Accessibility" | "Design";
export type Finding = {
  id: string; category: Category; title: string; status: "pass" | "issue" | "review";
  severity: "high" | "medium" | "low"; evidence: string; impact: string; fix: string;
  page: string; source: string; confidence: "Verified" | "Needs review";
};
export type PageEvidence = { url: string; title: string; description: string; headings: string[]; text: string; bytes: number; responseMs: number; };
export type Metrics = { strategy: string; status: "available" | "unavailable"; reason?: string; performance?: number; lcp?: number; cls?: number; tbt?: number; screenshot?: string; measuredAt?: string; };
export type ResearchNote = { headline:string; evidence:string; fix:string; strength:string; feedback:string; blog:string; angle:string; type:string; screenshot:string; reviewedAt:string; sources:string[] };
export type Audit = { id: string; url: string; company: string; contact: string; email: string; industry: string; status: string; createdAt: string; pages: PageEvidence[]; findings: Finding[]; metrics: Metrics[]; limitations: string[]; score: number | null; auditState?:"queued"|"running"|"complete"|"failed"; savedAt?:string; research?:ResearchNote; };
export type AuditJob = {id:string;auditId:string;url:string;company:string;type:"audit"|"speed";status:"queued"|"running"|"complete"|"failed";createdAt:string;updatedAt:string;attempts:number;leaseToken?:string;leaseUntil?:number;error?:string;warnings?:string[];auditVersion?:string};
export type Campaign = { id: string; auditId: string; company: string; email: string; createdAt: string; status: "Draft" | "Ready"; messages: {day: number; subject: string; body: string}[]; };
export type Article = { id: string; auditId: string; title: string; keyword: string; status: "Brief" | "Draft" | "Reviewed"; createdAt: string; publishDate: string; body: string; mode: "brief" | "ai"; };
export type Settings = { agency: string; sender: string; offer: string; signature: string; tone: "Helpful" | "Direct" | "Consultative"; autoCampaign: boolean; autoBrief: boolean; pagespeed: boolean; };
export const defaultSettings: Settings = { agency: "My agency", sender: "", offer: "a practical plan to improve your website", signature: "", tone: "Helpful", autoCampaign: true, autoBrief: true, pagespeed: true };
export const standards = [
  {category:"SEO", title:"Discoverable, understandable content", description:"Descriptive page titles, useful summaries, a clear heading structure, crawl access, and content that answers a real customer question.", href:"https://developers.google.com/search/docs/fundamentals/seo-starter-guide", label:"Google Search Central"},
  {category:"Performance", title:"Fast, responsive, stable", description:"Good field targets: LCP ≤ 2.5 s, INP ≤ 200 ms, CLS ≤ 0.1 at the 75th percentile. Lab tests are diagnostic snapshots, not real-user results.", href:"https://web.dev/articles/vitals", label:"Google Web Vitals"},
  {category:"Mobile", title:"Comfortable on a small screen", description:"A responsive viewport, readable content, usable controls, and content that reflows at 320 CSS pixels. A viewport tag alone does not prove mobile usability.", href:"https://www.w3.org/WAI/WCAG21/Understanding/reflow", label:"W3C · Reflow"},
  {category:"Accessibility", title:"Usable by more people", description:"Meaningful headings, text alternatives, a declared language, keyboard access, and sufficient text contrast. Automated checks cannot establish full compliance.", href:"https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html", label:"W3C · Contrast"},
  {category:"Design", title:"Clear, consistent, purposeful", description:"A clear offer, visible next step, consistent spacing and typography, credible trust signals, and no overlapping content. These are a review rubric, not an objective beauty score.", href:"https://www.w3.org/WAI/tutorials/page-structure/", label:"W3C · Page structure"},
];
