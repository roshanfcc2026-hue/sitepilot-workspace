import type {Audit, Campaign, Article, Settings} from "./types";

export function createCampaign(audit: Audit, settings: Settings): Campaign {
  const verified = audit.findings.filter(f=>f.status === "issue" && f.confidence === "Verified");
  const issues = verified.filter((f,i)=>verified.findIndex(x=>x.title===f.title)===i).slice(0,3);
  if (!issues.length) throw new Error("No verified issues to personalize a campaign. Review the report before contacting this prospect.");
  const greeting = audit.contact ? `Hi ${audit.contact},` : `Hi ${audit.company} team,`;
  const signoff = settings.signature || [settings.sender || "[Your name]",settings.agency].join("\n");
  const notes = issues.map(f=>`• ${f.title}: ${f.evidence}\n  Page checked: ${f.page}\n  Suggested improvement: ${f.fix}`).join("\n\n");
  const intro = settings.tone === "Direct" ? `I checked ${audit.url} and found ${issues.length === 1 ? "one specific improvement" : "a few specific improvements"}.` : settings.tone === "Consultative" ? `I took a look at ${audit.url} and identified a few areas worth discussing with your team.` : `I had a look at ${audit.url} and wanted to share a few useful observations.`;
  return {id:crypto.randomUUID(), auditId:audit.id, company:audit.company, email:audit.email, createdAt:new Date().toISOString(),status:"Draft", messages:[
    {day:0,subject:`A few website ideas for ${audit.company}`,body:`${greeting}\n\n${intro}\n\n${notes}\n\nThese observations are from the pages checked on ${audit.createdAt.slice(0,10)}; they aren't a prediction of traffic or revenue.\n\nAt ${settings.agency}, we can help with ${settings.offer}. Would it be useful if I sent over a short plan?\n\n${signoff}\n\nIf this isn't relevant, just let me know and I won't follow up.`},
    {day:3,subject:`One practical fix for ${audit.company}`,body:`${greeting}\n\nFollowing up with a concrete starting point from my review of ${audit.url}:\n\n${issues[0].fix}\n\n${issues[0].impact}\n\nHappy to explain what that would involve for your site. Is improving the website a priority right now?\n\n${signoff}`},
    {day:7,subject:`Should I close the loop?`,body:`${greeting}\n\nJust closing the loop on the website observations I shared for ${audit.company}. If you'd like help turning them into a prioritized plan, I'm happy to discuss it.\n\nIf the timing isn't right, no problem—I won't keep following up.\n\n${signoff}`}
  ]};
}

export function createBrief(audit: Audit, keyword?: string): Article {
  const topic = keyword?.trim() || `${audit.industry || audit.company} buyer's guide`;
  const sourceLinks = audit.pages.map(p=>`- [${p.title || p.url}](${p.url})`).join("\n");
  const description = audit.pages[0]?.description || "The fetched page did not provide a meta description. Confirm the business offer with the client.";
  return {id:crypto.randomUUID(), auditId:audit.id, title:`${topic}: a practical guide`, keyword:topic, status:"Brief",createdAt:new Date().toISOString(),publishDate:"",mode:"brief", body:`# ${topic}: a practical guide\n\n## Content brief\n\n**Client:** ${audit.company}\n**Primary topic:** ${topic}\n**Search intent:** Informational / commercial investigation (editorial hypothesis; validate against search results).\n**Audience:** People evaluating ${audit.industry || "the client's services"}.\n**Suggested length:** 900–1,200 words, only where useful.\n\n## Verified business context\n\n${description}\n\n## Suggested outline\n\n1. Answer the main question about ${topic} directly.\n2. Explain the options and who each is for.\n3. Describe the decision criteria, tradeoffs, and questions to ask.\n4. Add a practical checklist and one real example supplied by the client.\n5. Answer 3–5 customer questions without repeating the main text.\n6. End with a relevant next step for ${audit.company}.\n\n## On-page publishing checklist\n\n- Use a unique, descriptive title and one clear main heading.\n- Write an accurate meta description; avoid unsupported promises.\n- Link to the most relevant verified service page.\n- Add original experience, an author, and the reviewed date.\n- Add descriptive alt text to informative images.\n- Confirm every price, statistic, service claim, and testimonial with the client.\n\n## Source pages\n\n${sourceLinks}\n\n## Research still needed\n\nKeyword volume, ranking difficulty, competitors, and live search intent are not measured by this audit. Validate these before finalizing the topic. This is a content brief, not a finished blog article.`};
}

export function scoreFindings(findings: Audit["findings"]): number|null {
  const measured=findings.filter(f=>f.status!=="review");
  if(!measured.length) return null;
  const weight=(s:string)=>s==="high"?3:s==="medium"?2:1;
  return Math.round(100*measured.filter(f=>f.status==="pass").reduce((n,f)=>n+weight(f.severity),0)/measured.reduce((n,f)=>n+weight(f.severity),0));
}

export function csvCell(value:unknown) { let v=String(value??""); if(/^[\s]*[=+@\-]/.test(v))v="'"+v; return '"'+v.replaceAll('"','""')+'"'; }
