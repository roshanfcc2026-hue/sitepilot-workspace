import {db,get,put,insertStatement} from "./store";
import {recordId} from "./queue-model";
import {contactStages,activityTypes,channels,type Contact,type Activity} from "./outreach-model";
import type {Audit} from "./types";

export async function outreachData(who:string){
  const r=await db().prepare("SELECT kind, data FROM records WHERE owner = ? AND kind IN ('contact','activity') ORDER BY updated DESC").bind(who).all<{kind:string;data:string}>();
  return {contacts:r.results.filter(r=>r.kind==="contact").map(r=>JSON.parse(r.data) as Contact),activities:r.results.filter(r=>r.kind==="activity").map(r=>JSON.parse(r.data) as Activity)};
}
function field(value:unknown,max:number){if(typeof value!=="string"||value.length>max)throw new Error(`Use text with no more than ${max} characters.`);return value.trim();}
function day(value:unknown,optional=false){const s=field(value,10);if(optional&&!s)return "";if(!/^\d{4}-\d{2}-\d{2}$/.test(s)||!Number.isFinite(Date.parse(s))||new Date(s).toISOString().slice(0,10)!==s)throw new Error("Choose a valid date.");return s;}
export async function saveContact(who:string,input:any){
  const audit=await get<Audit>(who,field(input.auditId,200),"audit");if(!audit)throw new Error("Choose a website from your workspace.");
  const existing=input.id?await get<Contact>(who,field(input.id,200),"contact"):null;
  if(input.id&&!existing)throw new Error("Contact not found.");
  const name=field(input.name,100);if(!name)throw new Error("Add the person's name or a team name.");
  const email=field(input.email||"",200);if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw new Error("Add a valid email or leave it blank.");
  if(!contactStages.includes(input.stage))throw new Error("Choose a valid stage.");
  const now=new Date().toISOString();const contact:Contact={id:existing?.id||`contact:${crypto.randomUUID()}`,auditId:audit.id,name,email,phone:field(input.phone||"",60),role:field(input.role||"",100),stage:input.stage,followUp:day(input.followUp||"",true),nextStep:field(input.nextStep||"",400),notes:field(input.notes||"",5000),createdAt:existing?.createdAt||now,updatedAt:now};
  // Editing preserves concurrent changes rather than silently replacing another tab's record.
  if(existing){if(input.updatedAt!==existing.updatedAt)throw new Error("This contact changed in another tab. Reopen the contact before saving.");const r=await db().prepare("UPDATE records SET data = ?, updated = ? WHERE owner = ? AND id = ? AND kind = 'contact' AND data = ?").bind(JSON.stringify(contact),now,who,existing.id,JSON.stringify(existing)).run();if(!r.meta.changes)throw new Error("This contact changed. Reopen it before saving.");}
  else{const {contacts}=await outreachData(who);if(contacts.some(c=>c.auditId===contact.auditId&&(email?c.email.toLowerCase()===email.toLowerCase():c.name.toLowerCase()===name.toLowerCase())))throw new Error("This person is already saved for this website. Open their existing record.");await put(who,"contact",contact);}
  return contact;
}
export async function logActivity(who:string,input:any){
  const contact=await get<Contact>(who,field(input.contactId,200),"contact");if(!contact)throw new Error("Contact not found.");
  if(!activityTypes.includes(input.type)||!channels.includes(input.channel))throw new Error("Choose a valid activity and channel.");
  if(contact.stage==="Do not contact"&&["Message sent","Call made"].includes(input.type))throw new Error("This person is marked Do not contact. Update the stage before logging new outreach.");
  const key=field(input.requestId,100);if(!/^[a-zA-Z0-9-]{10,100}$/.test(key))throw new Error("Missing activity request ID.");
  const date=day(input.date);if(Date.parse(date)>Date.now()+86400000)throw new Error("Log completed conversations here. Use a follow-up date for future plans.");
  const activity:Activity={id:await recordId("activity",who,key),contactId:contact.id,type:input.type,channel:input.channel,date,note:field(input.note||"",5000),createdAt:new Date().toISOString(),removed:false};
  await insertStatement(who,"activity",activity).run();return activity;
}
export async function setActivityRemoved(who:string,id:string,removed:boolean){const activity=await get<Activity>(who,id,"activity");if(!activity)throw new Error("Activity not found.");await put(who,"activity",{...activity,removed});return {ok:true};}
