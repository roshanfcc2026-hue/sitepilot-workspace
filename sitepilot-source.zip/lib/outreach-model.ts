import type {Audit} from "./types";

export const contactStages = ["Auto","Meeting booked","Proposal sent","Won","In progress","Completed","Not interested","Do not contact"] as const;
export const activityTypes = ["Message sent","Reply received","Call made","Meeting","Note","Work started","Work completed"] as const;
export const channels = ["Email","Phone","LinkedIn","WhatsApp","Website form","In person","Other"] as const;
export type Contact = {id:string;auditId:string;name:string;email:string;phone:string;role:string;stage:typeof contactStages[number];followUp:string;nextStep:string;notes:string;createdAt:string;updatedAt:string};
export type Activity = {id:string;contactId:string;type:typeof activityTypes[number];channel:typeof channels[number];date:string;note:string;createdAt:string;removed:boolean};
export type OutreachFilter = "All people"|"Not contacted"|"Contacted"|"Replied"|"Follow-ups due"|"Clients";
export const localDay = (date=new Date()) => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;
export const activeHistory = (contact:Contact,activities:Activity[]) => activities.filter(a=>a.contactId===contact.id&&!a.removed).sort((a,b)=>b.date.localeCompare(a.date)||b.createdAt.localeCompare(a.createdAt));
export const reached = (history:Activity[]) => history.some(a=>["Message sent","Call made"].includes(a.type));
export const replied = (history:Activity[]) => history.some(a=>a.type==="Reply received");
export const isClient = (c:Contact,history:Activity[]=[]) => ["Won","In progress","Completed"].includes(c.stage)||history.some(a=>["Work started","Work completed"].includes(a.type));
export const followUpDue = (c:Contact,today=localDay()) => !!c.followUp&&c.followUp<=today&&!["Not interested","Do not contact","Completed"].includes(c.stage);
export function displayStage(c:Contact,history:Activity[]){if(c.stage!=="Auto")return c.stage;const work=history.find(a=>["Work started","Work completed"].includes(a.type));if(work)return work.type==="Work completed"?"Completed":"In progress";return replied(history)?"Replied":reached(history)?"Contacted":"Not contacted";}
export function matchesFilter(c:Contact,activities:Activity[],filter:OutreachFilter,today=localDay()){
  const history=activeHistory(c,activities);
  return filter==="All people"||filter==="Not contacted"&&!reached(history)||filter==="Contacted"&&reached(history)||filter==="Replied"&&replied(history)||filter==="Follow-ups due"&&followUpDue(c,today)||filter==="Clients"&&isClient(c,history);
}
export function outreachStats(audits:Audit[],contacts:Contact[],activities:Activity[],today=localDay()){
  const ids=new Set(contacts.map(c=>c.id));const active=activities.filter(a=>!a.removed&&ids.has(a.contactId));
  const reachedIds=new Set(active.filter(a=>["Message sent","Call made"].includes(a.type)).map(a=>a.contactId));
  const repliedIds=new Set(active.filter(a=>a.type==="Reply received").map(a=>a.contactId));
  const repliesToOutreach=[...repliedIds].filter(id=>reachedIds.has(id)).length;
  const workedIds=new Set(active.filter(a=>["Work started","Work completed"].includes(a.type)).map(a=>a.contactId));
  const workedWebsites=new Set(contacts.filter(c=>["In progress","Completed"].includes(c.stage)||workedIds.has(c.id)).map(c=>c.auditId));
  return {websites:audits.length,analyzed:audits.filter(a=>a.pages.length>0).length,people:contacts.length,contacted:reachedIds.size,replied:repliedIds.size,messages:active.filter(a=>a.type==="Message sent").length,replyCount:active.filter(a=>a.type==="Reply received").length,responseRate:reachedIds.size?Math.round(repliesToOutreach/reachedIds.size*100):null,followUps:contacts.filter(c=>followUpDue(c,today)).length,won:new Set(contacts.filter(c=>isClient(c,activeHistory(c,active))).map(c=>c.auditId)).size,worked:workedWebsites.size};
}
