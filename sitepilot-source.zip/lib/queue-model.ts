import {publicUrl} from "./audit";
import type {AuditJob} from "./types";

export function websiteKey(input:string){const url=publicUrl(input.trim());url.searchParams.sort();return url.hostname.toLowerCase().replace(/^www\./,"")+url.pathname.replace(/\/+$/,"")+url.search;}
export async function recordId(kind:string,owner:string,key:string){const bytes=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(JSON.stringify([owner,key])));return `${kind}:${Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,"0")).join("")}`;}
export function runnable(job:AuditJob,now=Date.now()){return job.status==="queued"||(job.status==="running"&&(job.leaseUntil||0)<now);}
export function freshJob(auditId:string,url:string,company:string,type:AuditJob["type"]):AuditJob{const now=new Date().toISOString();return {id:`${type}-job:${auditId}`,auditId,url,company,type,status:"queued",createdAt:now,updatedAt:now,attempts:0};}
