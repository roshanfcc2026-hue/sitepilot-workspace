import research from "./data/construction-research.json";
import {get,list,insertMany} from "./store";
import {recordId,websiteKey} from "./queue-model";
import {createCampaign,createBrief,scoreFindings} from "./content";
import {defaultSettings,type Audit,type Settings} from "./types";

export async function importResearch(who:string){
  const receiptId=await recordId("import",who,"construction-research-oct-2026-v1");
  const receipt=await get<{count:number}>(who,receiptId,"system");if(receipt)return receipt;
  const existing=await list<Audit>(who,"audit");const known=new Set(existing.map(a=>websiteKey(a.url)));
  const settings=await get<Settings>(who,`settings:${who}`,"settings")||defaultSettings;
  const items:{kind:string;data:{id:string}}[]=[];let count=0;
  for(const source of research as unknown as Audit[]){const key=websiteKey(source.url);if(known.has(key))continue;
    const audit:Audit={...source as Audit,id:await recordId("audit",who,key),savedAt:new Date().toISOString(),score:scoreFindings(source.findings as Audit["findings"])};
    items.push({kind:"audit",data:audit});
    if(settings.autoCampaign&&audit.findings.some(f=>f.status==="issue"))items.push({kind:"campaign",data:{...createCampaign(audit,settings),id:`auto-campaign:${audit.id}`}});
    if(settings.autoBrief){const brief=createBrief(audit,audit.research?.blog);brief.body+=`\n\n## Specific editorial direction\n\n${audit.research?.angle||""}`;items.push({kind:"article",data:{...brief,id:`auto-brief:${audit.id}`}});}
    count++;
  }
  const saved={id:receiptId,count,completedAt:new Date().toISOString()};items.push({kind:"system",data:saved});
  // The receipt and every imported output commit together. Repeated visits never overwrite edits.
  await insertMany(who,items);return saved;
}
