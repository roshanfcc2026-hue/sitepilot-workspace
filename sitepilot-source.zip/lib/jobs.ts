import {env} from "cloudflare:workers";
import {db,get,list,put,insertMany} from "./store";
import {publicUrl,runAudit,pageSpeed} from "./audit";
import {createCampaign,createBrief,scoreFindings} from "./content";
import {recordId,websiteKey,freshJob,runnable} from "./queue-model";
import {defaultSettings,type Audit,type AuditJob,type Settings,type Metrics} from "./types";

export async function queueWebsites(who:string,input:{urls?:unknown;company?:unknown;contact?:unknown;email?:unknown;industry?:unknown;reauditId?:unknown}){
  if(input.reauditId){const audit=await get<Audit>(who,String(input.reauditId),"audit");if(!audit)throw new Error("Website not found.");const job=freshJob(audit.id,audit.url,audit.company,"audit");const current=await get<AuditJob>(who,job.id,"job");if(current?.status==="running"||current?.status==="queued")return {added:0,skipped:1};await put(who,"job",job);return {added:1,skipped:0};}
  if(!Array.isArray(input.urls)||!input.urls.length||input.urls.length>20||input.urls.some(u=>typeof u!=="string"||u.length>2000))throw new Error("Add between 1 and 20 public website URLs.");
  const urls=input.urls.map(u=>publicUrl(u.trim()).href);const saved=await list<Audit>(who,"audit");const seen=new Set(saved.map(a=>websiteKey(a.url)));const items:{kind:string;data:Audit|AuditJob}[]=[];let added=0,skipped=0;
  for(const url of urls){const key=websiteKey(url);if(seen.has(key)){skipped++;continue;}seen.add(key);const id=await recordId("audit",who,key);const now=new Date().toISOString();const audit:Audit={id,url,company:urls.length===1&&input.company?String(input.company).trim().slice(0,150):new URL(url).hostname.replace(/^www\./,""),contact:urls.length===1?String(input.contact||"").slice(0,100):"",email:urls.length===1?String(input.email||"").slice(0,200):"",industry:String(input.industry||"").slice(0,150),status:"Audited",auditState:"queued",createdAt:now,savedAt:now,pages:[],findings:[],metrics:[],limitations:["Website saved. Evidence checks are queued."],score:null};items.push({kind:"audit",data:audit},{kind:"job",data:freshJob(id,url,audit.company,"audit")});added++;}
  await insertMany(who,items);return {added,skipped};
}

export async function saveOutputs(who:string,audit:Audit,settings:Settings){
  const outputs:{kind:string;data:{id:string}}[]=[];
  if(settings.autoCampaign&&audit.findings.some(f=>f.status==="issue"&&f.confidence==="Verified"))outputs.push({kind:"campaign",data:{...createCampaign(audit,settings),id:`auto-campaign:${audit.id}`}});
  if(settings.autoBrief)outputs.push({kind:"article",data:{...createBrief(audit,audit.research?.blog),id:`auto-brief:${audit.id}`}});
  await insertMany(who,outputs);
}

async function claim(who:string,id:string){
  const current=await get<AuditJob>(who,id,"job");if(!current)throw new Error("Saved task not found.");if(!runnable(current))return null;
  const now=Date.now();const job={...current,status:"running" as const,leaseToken:crypto.randomUUID(),leaseUntil:now+300000,attempts:current.attempts+1,updatedAt:new Date().toISOString(),error:undefined};
  const result=await db().prepare("UPDATE records SET data = ?, updated = ? WHERE owner = ? AND id = ? AND kind = 'job' AND (json_extract(data,'$.status') = 'queued' OR (json_extract(data,'$.status') = 'running' AND COALESCE(json_extract(data,'$.leaseUntil'),0) < ?))").bind(JSON.stringify(job),job.updatedAt,who,id,now).run();
  return result.meta.changes?job:null;
}

// Both writes check the same lease, so a delayed request cannot overwrite a newer run.
async function complete(who:string,job:AuditJob,audit:Audit,expected:Audit,extra:{kind:string;data:{id:string}}[]=[]){
  const now=new Date().toISOString();const finished={...job,status:"complete",leaseUntil:0,updatedAt:now};
  const result=await db().batch([
    db().prepare("UPDATE records SET data = ?, updated = ? WHERE owner = ? AND id = ? AND kind = 'audit' AND data = ? AND EXISTS (SELECT 1 FROM records j WHERE j.owner = ? AND j.id = ? AND j.kind = 'job' AND json_extract(j.data,'$.leaseToken') = ? AND json_extract(j.data,'$.status') = 'running')").bind(JSON.stringify(audit),now,who,audit.id,JSON.stringify(expected),who,job.id,job.leaseToken),
    ...extra.map(x=>db().prepare("INSERT OR IGNORE INTO records (id,owner,kind,data,updated) SELECT ?,?,?,?,? WHERE EXISTS (SELECT 1 FROM records a WHERE a.id = ? AND a.owner = ? AND a.kind = 'audit' AND a.data = ?) AND EXISTS (SELECT 1 FROM records j WHERE j.id = ? AND j.owner = ? AND j.kind = 'job' AND json_extract(j.data,'$.leaseToken') = ? AND json_extract(j.data,'$.status') = 'running')").bind(x.data.id,who,x.kind,JSON.stringify(x.data),now,audit.id,who,JSON.stringify(audit),job.id,who,job.leaseToken)),
    db().prepare("UPDATE records SET data = ?, updated = ? WHERE owner = ? AND id = ? AND kind = 'job' AND json_extract(data,'$.leaseToken') = ? AND json_extract(data,'$.status') = 'running' AND EXISTS (SELECT 1 FROM records a WHERE a.id = ? AND a.owner = ? AND a.kind = 'audit' AND a.data = ?)").bind(JSON.stringify(finished),now,who,job.id,job.leaseToken,audit.id,who,JSON.stringify(audit))
  ]);
  if(!result[result.length-1].meta.changes)throw new Error("The report changed during this check. Your newer data is safe; retry the check.");
}

export async function runJob(who:string,id:string){
  const job=await claim(who,id);if(!job)return {claimed:false};
  try{
    const original=await get<Audit>(who,job.auditId,"audit");if(!original)throw new Error("The saved website is no longer available.");
    const settings=await get<Settings>(who,`settings:${who}`,"settings")||defaultSettings;
    if(job.type==="audit"){
      const measured=await runAudit({...original,pagespeed:false});
      const latest=await get<Audit>(who,job.auditId,"audit")||original;
      const audit:Audit={...measured,id:original.id,status:latest.status,contact:latest.contact,email:latest.email,company:latest.company,industry:latest.industry,auditState:"complete",savedAt:new Date().toISOString(),research:latest.research,limitations:measured.limitations.filter(l=>!l.startsWith("PageSpeed tests were switched off"))};
      audit.limitations.push(settings.pagespeed?"Speed tests run separately after the HTML report is saved.":"Speed tests are disabled in workflow settings.");
      if(audit.research)audit.limitations.push("The prior browser review has its own date. Its observations are not revalidated by this HTML refresh.");
      let speedJob:AuditJob|undefined;
      if(settings.pagespeed)speedJob={...freshJob(audit.id,audit.url,audit.company,"speed"),id:`speed-job:${audit.id}:${job.leaseToken}`,auditVersion:audit.createdAt};
      await complete(who,job,audit,latest,speedJob?[{kind:"job",data:speedJob}]:[]);
      try{await saveOutputs(who,audit,settings);}catch{await put(who,"job",{...job,status:"complete",leaseUntil:0,warnings:["Report saved. Generate the campaign or brief from its report if needed."],updatedAt:new Date().toISOString()});}
    }else{
      const stateId=`speed-state:${who}`;const state=await get<{until:number}>(who,stateId,"system");let metrics:Metrics[];let speedFindings:Audit["findings"]=[];
      if(state&&state.until>Date.now())metrics=["mobile","desktop"].map(strategy=>({strategy,status:"unavailable",reason:"Google's quota is temporarily exhausted. Your HTML report is saved. Retry speed tests after the cooldown."}));
      else{
        const mobile=await pageSpeed(original.url,"mobile",env.PAGESPEED_API_KEY);
        const quota=mobile.metric.status==="unavailable"&&/quota|429/i.test(mobile.metric.reason||"");
        if(quota){await put(who,"system",{id:stateId,until:Date.now()+1800000});metrics=[mobile.metric,{strategy:"desktop",status:"unavailable",reason:"Skipped because Google's quota was exhausted by the mobile request. Your HTML report is saved."}];}
        else{const desktop=await pageSpeed(original.url,"desktop",env.PAGESPEED_API_KEY);metrics=[mobile.metric,desktop.metric];speedFindings=[...mobile.findings,...desktop.findings];}
      }
      const latest=await get<Audit>(who,job.auditId,"audit")||original;const findings=[...latest.findings.filter(f=>!f.source.startsWith("Google Lighthouse")),...speedFindings];
      await complete(who,job,job.auditVersion&&job.auditVersion!==latest.createdAt?{...latest,savedAt:new Date().toISOString()}:{...latest,metrics,findings,score:scoreFindings(findings),savedAt:new Date().toISOString()},latest);
    }
    return {claimed:true};
  }catch(e){const message=e instanceof Error?e.message:"The check did not complete. Retry this saved task.";const failed={...job,status:"failed",leaseUntil:0,error:message,updatedAt:new Date().toISOString()};await db().prepare("UPDATE records SET data = ?, updated = ? WHERE owner = ? AND id = ? AND kind = 'job' AND json_extract(data,'$.leaseToken') = ?").bind(JSON.stringify(failed),failed.updatedAt,who,job.id,job.leaseToken).run();return {claimed:true,error:message};}
}

export async function retryJob(who:string,id:string){const job=await get<AuditJob>(who,id,"job");if(!job)throw new Error("Task not found.");if(job.status!=="failed")throw new Error("Only failed tasks can be retried.");await db().prepare("UPDATE records SET data = ?, updated = ? WHERE owner = ? AND id = ? AND kind = 'job' AND json_extract(data,'$.status') = 'failed'").bind(JSON.stringify({...job,status:"queued",error:undefined,leaseUntil:0,updatedAt:new Date().toISOString()}),new Date().toISOString(),who,id).run();}

export async function queueSpeed(who:string,auditId:string){const audit=await get<Audit>(who,auditId,"audit");if(!audit?.pages.length)throw new Error("Complete the website evidence check first.");const state=await get<{until:number}>(who,`speed-state:${who}`,"system");if(state&&state.until>Date.now())throw new Error(`Google's quota is cooling down. Try again in ${Math.ceil((state.until-Date.now())/60000)} minutes. Your report is already saved.`);const pending=(await list<AuditJob>(who,"job")).find(j=>j.auditId===auditId&&(j.status==="queued"||j.status==="running"));if(pending)return {added:0};await put(who,"job",{...freshJob(audit.id,audit.url,audit.company,"speed"),auditVersion:audit.createdAt});return {added:1};}
