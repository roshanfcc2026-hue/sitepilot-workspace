import type {Audit, Finding} from "./types";

const sentences = (value:string) => value.replace(/\s+/g," ").trim();
const join = (items:string[]) => items.length < 2 ? items[0] : `${items.slice(0,-1).join(", ")} and ${items.at(-1)}`;
const priorities:Record<string,string> = {
  "Descriptive page title":"missing page titles",
  "Meta description":"missing search-result descriptions",
  "Main heading":"missing main headings",
  "Indexing directive":"pages marked to stay out of search results",
  "Responsive viewport":"missing mobile viewport settings",
  "Pinch zoom":"restrictions on zooming in",
  "Page language":"missing page-language information for assistive technology",
  "Image text alternatives":"images without text alternatives",
};
const priority = (finding:Finding) => priorities[finding.title] || finding.title.replace(/^[A-Z]/,c=>c.toLowerCase());

export function overallSummary(audit:Audit):{text:string;ready:boolean} {
  const researched = audit.research?.feedback.trim() && Date.parse(audit.research.reviewedAt) >= Date.parse(audit.createdAt);
  const ready = !!researched || audit.pages.length > 0;
  if(!ready)return {ready:false,text:audit.auditState === "failed"
    ? "Your website is saved, but the checks could not finish. Retry the audit to create a summary based on actual findings."
    : "Your website is saved. A personalized summary will appear here once the checks finish."};

  const dateValue = researched ? audit.research!.reviewedAt : audit.createdAt;
  const date = Number.isNaN(Date.parse(dateValue)) ? "" : ` on ${new Date(dateValue).toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric",timeZone:"UTC"})}`;
  const opening = `I reviewed ${sentences(audit.company)}’s website${date}.`;
  // Older visual research stays in its evidence section; refreshed summaries use the new checks.
  if(researched)return {ready:true,text:`${opening} ${sentences(audit.research!.feedback)}`};

  const severity = {high:0,medium:1,low:2};
  const verified = audit.findings.filter(f=>f.status === "issue" && f.confidence === "Verified")
    .sort((a,b)=>severity[a.severity]-severity[b.severity]);
  const unique = verified.filter((f,i)=>verified.findIndex(other=>other.title === f.title) === i).slice(0,3);
  const scope = `${audit.pages.length} page${audit.pages.length === 1 ? "" : "s"} sampled`;
  if(!unique.length)return {ready:true,text:`${opening} The ${scope} had no verified issues in the checks completed. ${audit.findings.some(f=>f.status === "review") ? "Some areas still need a closer review before recommending changes." : "This is a limited sample, so it does not establish that the whole website is free of issues."}`};
  const fixes = [...new Set(unique.map(f=>sentences(f.fix)).filter(Boolean))].slice(0,2);
  return {ready:true,text:`${opening} Across the ${scope}, the clearest priorities are ${join(unique.map(priority))}. ${fixes.length ? `My recommended next steps: ${fixes.join(" ")}` : "The detailed report includes the evidence for each observation."}`};
}
