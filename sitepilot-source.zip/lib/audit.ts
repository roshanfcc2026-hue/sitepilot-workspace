import type {Audit, Category, Finding, Metrics, PageEvidence} from "./types";
import {scoreFindings} from "./content";

export function publicUrl(input:string): URL {
  const url=new URL(input.includes("://")?input:`https://${input}`);
  const h=url.hostname.toLowerCase().replace(/\.$/,"");
  if(!["http:","https:"].includes(url.protocol) || url.username || url.password || (url.port && !["80","443"].includes(url.port))) throw new Error("Use a public HTTP or HTTPS website without credentials or a custom port.");
  if(!h.includes(".") || h.includes(":") || /(^|\.)(localhost|local|internal|test|invalid|example|onion)$/.test(h) || /^\d+(\.\d+){3}$/.test(h)) throw new Error("Use a public domain name; local and numeric addresses are not supported.");
  url.hash="";return url;
}
function privateIp(ip:string):boolean {
  if(ip.includes(":")) return /^(::|f[cd]|fe[89ab]|ff|2001:db8)/i.test(ip) || ip.includes(".") || /^(64:ff9b|2002:)/i.test(ip);
  const [a,b]=ip.split(".").map(Number);return a===0 || a===10 || a===127 || a>=224 || (a===169&&b===254) || (a===172&&b>=16&&b<=31) || (a===192&&(b===168||b===0)) || (a===100&&b>=64&&b<=127) || (a===198&&(b===18||b===19));
}
async function checkDns(host:string) {
  const answers=await Promise.all(["A","AAAA"].map(async type=>{
    const r=await fetch(`https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(host)}&type=${type}`,{headers:{Accept:"application/dns-json"},signal:AbortSignal.timeout(8000)});
    if(!r.ok)throw new Error("Public DNS validation is unavailable. Try again shortly.");
    const d=await r.json() as {Answer?:{type:number,data:string}[]};return (d.Answer||[]).filter(a=>[1,28].includes(a.type)).map(a=>a.data);
  }));
  const ips=answers.flat();if(!ips.length||ips.some(privateIp))throw new Error("The website does not resolve exclusively to public internet addresses.");
}
async function fetchPublic(input:string):Promise<{html:string;url:string;bytes:number;responseMs:number;headers:Headers}> {
  let url=publicUrl(input);
  for(let hop=0;hop<5;hop++) {
    await checkDns(url.hostname);
    const start=Date.now();
    const response=await fetch(url,{redirect:"manual",headers:{"User-Agent":"SitepilotAudit/1.0 (+website quality review)",Accept:"text/html,text/plain,application/xml;q=0.8"},signal:AbortSignal.timeout(18000)});
    if([301,302,303,307,308].includes(response.status)){const loc=response.headers.get("location");await response.body?.cancel();if(!loc)throw new Error("Redirect without a destination.");url=publicUrl(new URL(loc,url).href);continue;}
    if(!response.ok){await response.body?.cancel();throw new Error(`The website returned HTTP ${response.status}. It may restrict automated access.`);}
    if(!/text|xml|html/i.test(response.headers.get("content-type")||"")){await response.body?.cancel();throw new Error("This address did not return a web page.");}
    const reader=response.body?.getReader();if(!reader)throw new Error("Empty response.");
    let bytes=0,html="";const decoder=new TextDecoder();
    while(true){const part=await reader.read();if(part.done)break;bytes+=part.value.length;if(bytes>1500000){await reader.cancel();throw new Error("The page exceeds the 1.5 MB HTML limit.");}html+=decoder.decode(part.value,{stream:true});}html+=decoder.decode();
    return {html,url:url.href,bytes,responseMs:Date.now()-start,headers:response.headers};
  }throw new Error("Too many redirects.");
}
const decode=(s:string)=>s.replace(/&#(x[0-9a-f]+|\d+);/gi,(_,n)=>{const c=n[0].toLowerCase()==="x"?parseInt(n.slice(1),16):+n;return c>0&&c<=0x10ffff?String.fromCodePoint(c):"";}).replace(/&amp;/g,"&").replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&nbsp;/g," ");
const text=(s:string)=>decode(s.replace(/<[^>]+>/g," ")).replace(/\s+/g," ").trim();
function attrs(tag:string) {const out:Record<string,string>={};const re=/([^\s=<>/]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g;for(const m of tag.matchAll(re))out[m[1].toLowerCase()]=decode(m[2]??m[3]??m[4]??"");return out;}

export function analyzeHtml(html:string,url:string,bytes:number,responseMs:number,headers=new Headers()):{page:PageEvidence;findings:Finding[];links:string[]} {
  const clean=html.replace(/<!--[\s\S]*?-->/g,"").replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi,"").replace(/<style\b[^>]*>[\s\S]*?<\/style\s*>/gi,"");
  const metas=Array.from(clean.matchAll(/<meta\b[^>]*>/gi),m=>attrs(m[0]));
  const meta=(name:string)=>metas.find(m=>(m.name||m.property||"").toLowerCase()===name)?.content||"";
  const title=text(clean.match(/<title\b[^>]*>([\s\S]*?)<\/title\s*>/i)?.[1]||"");
  const headings=Array.from(clean.matchAll(/<h1\b[^>]*>([\s\S]*?)<\/h1\s*>/gi),m=>text(m[1]));
  const images=Array.from(clean.matchAll(/<img\b[^>]*>/gi),m=>attrs(m[0]));
  const anchors=Array.from(clean.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi),m=>({attrs:attrs(m[1]),label:text(m[2])}));
  const links=anchors.map(a=>a.attrs.href).filter(Boolean).map(h=>{try{return new URL(h,url).href;}catch{return "";}}).filter(Boolean);
  const findings:Finding[]=[];
  const add=(category:Category,name:string,ok:boolean|null,evidence:string,impact:string,fix:string,severity:Finding["severity"]="medium")=>findings.push({id:crypto.randomUUID(),category,title:name,status:ok===null?"review":ok?"pass":"issue",severity,evidence,impact,fix,page:url,source:"Fetched HTML",confidence:ok===null?"Needs review":"Verified"});
  add("SEO","Descriptive page title",!!title,title?`Page title: “${title.slice(0,180)}”`:"No non-empty title element was found in the fetched HTML.","A clear title helps people and search engines understand the page.","Add a unique title that accurately describes the page and business.","high");
  add("SEO","Meta description",!!meta("description"),meta("description")?`Description: “${meta("description").slice(0,220)}”`:"No non-empty meta description was found in the fetched HTML.","A useful description can inform the search snippet; Google may choose different text.","Write a specific summary of the page's offer and who it helps.");
  add("SEO","Main heading",headings.some(Boolean),headings.length?`${headings.length} H1 element(s): ${headings.join(" · ").slice(0,220)}`:"No H1 heading was found in the fetched HTML.","A descriptive main heading makes the page purpose easier to identify.","Add a clear main heading that explains the page's subject.");
  const noindex=/\bnoindex\b/i.test(meta("robots")+" "+meta("googlebot")+" "+(headers.get("x-robots-tag")||""));
  add("SEO","Indexing directive",!noindex,noindex?"A noindex directive is present in page metadata or response headers.":"No noindex directive was found in the checked metadata or response headers. This does not prove indexing.","A noindex directive asks search engines to exclude this page.","Confirm whether exclusion is intentional; remove noindex only for pages intended for search.","high");
  const canonical=Array.from(clean.matchAll(/<link\b[^>]*>/gi),m=>attrs(m[0])).find(a=>a.rel?.split(/\s+/).includes("canonical"))?.href;
  add("SEO","Canonical URL",canonical?true:null,canonical?`Declared canonical: ${canonical}`:"No canonical link was found. This is not automatically an SEO error.","Canonical hints can clarify the preferred URL where duplicate pages exist.","Check for duplicate URLs before deciding whether a canonical link is needed.","low");
  const viewport=meta("viewport");
  add("Mobile","Responsive viewport",/width\s*=\s*device-width/i.test(viewport),viewport?`Viewport: ${viewport}`:"No viewport meta tag was found in the fetched HTML.","Without an appropriate viewport, mobile browsers may scale a desktop-width layout.","Use a width=device-width viewport and test the rendered page at common mobile widths.","high");
  const restrictedZoom=/user-scalable\s*=\s*(no|0)|maximum-scale\s*=\s*1(?:\D|$)/i.test(viewport);
  add("Mobile","Pinch zoom",!restrictedZoom,restrictedZoom?`The viewport restricts zoom: ${viewport}`:"No zoom restriction was found in the viewport tag.","Visitors with low vision may need to zoom in to read content.","Remove user-scalable=no and restrictive maximum-scale settings.");
  const language=attrs(clean.match(/<html\b[^>]*>/i)?.[0]||"").lang;
  add("Accessibility","Page language",!!language,language?`Document language: ${language}`:"No lang value was found on the HTML element.","A declared language helps assistive technology pronounce text correctly.","Set the HTML lang attribute to the page's primary language.");
  const missingAlt=images.filter(i=>!("alt" in i));
  if(images.length)add("Accessibility","Image text alternatives",missingAlt.length===0,`${missingAlt.length} of ${images.length} image elements lack an alt attribute.${missingAlt[0]?` Example: ${(missingAlt[0].src||"inline image").slice(0,120)}`:" Empty alt attributes still need context review."}`,"Informative images need equivalent text for people using screen readers.","Add meaningful alt text to informative images; use empty alt text for decorative images.");
  const unsized=images.filter(i=>!i.width||!i.height);
  if(unsized.length)add("Design","Reserved image space",null,`${unsized.length} image elements lack HTML width or height attributes. CSS sizing was not inspected.`,"Unreserved image space can contribute to layout movement, but CSS may already reserve it.","Check computed image dimensions or aspect-ratio and confirm with a layout-shift test.");
  add("Design","Visual hierarchy & layout",null,"HTML-only checks cannot judge spacing, brand consistency, overlap, or the clarity of the first screen.","Consistent typography and a clear next step help visitors navigate the offer.","Review a rendered desktop and mobile screenshot, hierarchy, primary action, and trust signals.");
  add("Mobile","Small-screen layout",null,"Horizontal overflow and tap-target usability have not been measured in a rendered browser.","Content should remain readable and usable on small screens.","Test at 320, 375, and 768 CSS pixels; check clipping, navigation, forms, and touch targets.","high");
  add("Performance","HTML response measurement",null,`HTML fetch and body read: ${responseMs} ms, ${Math.round(bytes/1024)} KB. This excludes images, CSS, scripts, and rendering.`,"A server-side HTML request is not a page load time or a Core Web Vitals result.","Use the mobile and desktop PageSpeed lab results for rendering diagnostics; consult field data for real users.");
  const visible=text(clean.replace(/<head\b[^>]*>[\s\S]*?<\/head>/i,""));
  if(visible.length<150&&/<script\b[^>]*\bsrc\s*=/i.test(html))for(const finding of findings){if(finding.status==="issue"&&["Main heading","Descriptive page title","Meta description"].includes(finding.title)){finding.status="review";finding.confidence="Needs review";finding.evidence+=" This page appears to rely on JavaScript; verify the rendered page before treating the omission as a defect.";}}
  if(visible.length<150)add("SEO","Limited server-rendered content",null,`Only ${visible.length} visible-text characters were extracted. The page may rely on JavaScript.`,"Raw HTML findings may differ from the fully rendered page.","Inspect the rendered page and search-engine rendering before treating absent HTML elements as site-wide issues.","high");
  return {page:{url,title,description:meta("description"),headings,text:visible.slice(0,6000),bytes,responseMs},findings,links};
}

function robotsAllowed(body:string,path:string):boolean {
  let active=false,hadRules=false;const rules:{allow:boolean;path:string}[]=[];
  for(const line of body.split(/\r?\n/)){const m=line.split("#")[0].trim().match(/^([\w-]+)\s*:\s*(.*)$/);if(!m)continue;const key=m[1].toLowerCase(),value=m[2].trim();if(key==="user-agent"){if(hadRules){active=false;hadRules=false;}active=active||value==="*"||value.toLowerCase().includes("sitepilotaudit");}else if(["allow","disallow"].includes(key)){hadRules=true;if(active&&value)rules.push({allow:key==="allow",path:value});}}
  const matches=rules.filter(r=>new RegExp("^"+r.path.replace(/[.+?^${}()|[\]\\]/g,"\\$&").replace(/\*/g,".*").replace(/\\\$$/,"$")).test(path)).sort((a,b)=>b.path.length-a.path.length||Number(b.allow)-Number(a.allow));
  return matches[0]?.allow??true;
}
export async function pageSpeed(url:string,strategy:"mobile"|"desktop",key?:string):Promise<{metric:Metrics;findings:Finding[]}> {
  try{
    const api=new URL("https://www.googleapis.com/pagespeedonline/v5/runPagespeed");api.searchParams.set("url",url);api.searchParams.set("strategy",strategy);api.searchParams.append("category","performance");api.searchParams.append("category","accessibility");if(key)api.searchParams.set("key",key);
    const r=await fetch(api,{signal:AbortSignal.timeout(65000)});
    if(!r.ok)throw new Error(r.status===429?"Google's test quota is currently exhausted. Configure a PageSpeed key or retry later.":`PageSpeed returned HTTP ${r.status}.`);
    const d=await r.json() as any;const lh=d.lighthouseResult;if(!lh||lh.runtimeError)throw new Error(lh?.runtimeError?.message||"PageSpeed did not return a completed test.");
    const audits=lh.audits;const metric:Metrics={strategy,status:"available",performance:Math.round(lh.categories.performance.score*100),lcp:audits["largest-contentful-paint"]?.numericValue,cls:audits["cumulative-layout-shift"]?.numericValue,tbt:audits["total-blocking-time"]?.numericValue,measuredAt:lh.fetchTime,screenshot:audits["final-screenshot"]?.details?.data};
    const findings:Finding[]=[];
    for(const [id,category] of [["largest-contentful-paint","Performance"],["cumulative-layout-shift","Design"],["color-contrast","Accessibility"],["target-size","Mobile"]] as const){const a=audits[id];if(!a||a.score===null)continue;const pass=id==="largest-contentful-paint"?a.numericValue<=2500:id==="cumulative-layout-shift"?a.numericValue<=0.1:a.score===1;findings.push({id:crypto.randomUUID(),category,title:`${a.title} · ${strategy}`,status:pass?"pass":"issue",severity:"high",confidence:"Verified",page:url,source:`Google Lighthouse · ${strategy} lab test`,evidence:`${a.displayValue||`Audit score: ${Math.round(a.score*100)}/100`}. Captured ${lh.fetchTime}.${a.details?.items?.[0]?.node?.snippet?` Element: ${a.details.items[0].node.snippet.slice(0,220)}`:""}`,impact:id==="largest-contentful-paint"?"This lab measurement indicates how quickly the main content appeared in this test.":id==="cumulative-layout-shift"?"This lab test measures unexpected layout movement during page load.":"This automated check identified a usability condition on the rendered page.",fix:String(a.description||"Review the Lighthouse diagnostic and affected elements.").replace(/\[([^\]]+)\]\([^)]+\)/g,"$1")});}
    return {metric,findings};
  }catch(e){return {metric:{strategy,status:"unavailable",reason:e instanceof Error?e.message:"PageSpeed was unavailable."},findings:[]};}
}

export async function runAudit(input:{url:string;company?:string;contact?:string;email?:string;industry?:string;pagespeed?:boolean},key?:string):Promise<Audit> {
  const initial=publicUrl(input.url);let robots="";const limitations=["Up to 3 public pages are sampled; this is not a full-site crawl.","HTML checks inspect the server response. JavaScript-rendered content may differ.","The health score is a weighted pass rate for measured checks, not a Google score or ranking prediction.","Aesthetic quality, live search rankings, keyword volume, and conversions are not measured."];
  try{robots=(await fetchPublic(new URL("/robots.txt",initial).href)).html;}catch{limitations.push("robots.txt could not be read; no crawl-access conclusion was drawn.");}
  if(!robotsAllowed(robots,initial.pathname+initial.search))throw new Error("This path is disallowed for automated crawlers in robots.txt.");
  const first=await fetchPublic(initial.href);const firstData=analyzeHtml(first.html,first.url,first.bytes,first.responseMs,first.headers);
  const origin=new URL(first.url).origin;let finalRobots=robots;
  if(origin!==initial.origin){try{finalRobots=(await fetchPublic(origin+"/robots.txt")).html;}catch{finalRobots="";}}
  const candidates=[...new Set(firstData.links.filter(l=>{try{const u=new URL(l);return u.origin===origin&&u.pathname!==new URL(first.url).pathname&&!u.search&&!u.hash&&/about|services|solutions|contact|products/i.test(u.pathname)&&!(/login|admin|logout|checkout|cart|delete|unsubscribe/i.test(u.pathname))&&robotsAllowed(finalRobots,u.pathname);}catch{return false;}}))].slice(0,2);
  const additional=await Promise.all(candidates.map(async url=>{try{const p=await fetchPublic(url);if(new URL(p.url).origin!==origin)return null;return analyzeHtml(p.html,p.url,p.bytes,p.responseMs,p.headers);}catch(e){limitations.push(`Could not inspect ${url}: ${e instanceof Error?e.message:"request failed"}`);return null;}}));
  const result=[firstData,...additional.filter((a):a is typeof firstData=>!!a)];
  const speed=input.pagespeed===false?[]:await Promise.all([pageSpeed(first.url,"mobile",key),pageSpeed(first.url,"desktop",key)]);
  if(!speed.length)limitations.push("PageSpeed tests were switched off for this audit.");
  const findings=[...result.flatMap(r=>r.findings),...speed.flatMap(s=>s.findings)].sort((a,b)=>({issue:0,review:1,pass:2}[a.status]-{issue:0,review:1,pass:2}[b.status])||({high:0,medium:1,low:2}[a.severity]-{high:0,medium:1,low:2}[b.severity]));
  return {id:crypto.randomUUID(),url:first.url,company:input.company?.trim()||new URL(first.url).hostname.replace(/^www\./,""),contact:input.contact||"",email:input.email||"",industry:input.industry||"",status:"Audited",createdAt:new Date().toISOString(),pages:result.map(r=>r.page),findings,metrics:speed.map(s=>s.metric),limitations,score:scoreFindings(findings)};
}
