# Sitepilot — Personal website & outreach workspace

A private workspace for reviewing websites, keeping a contact book, tracking conversations and follow-ups, and preparing campaign drafts and SEO content briefs.

## Features

- Personal dashboard: websites analyzed, unique people contacted, people who replied, messages sent, reply rate, websites won, and websites worked on.
- Contact records linked to websites, with names, roles, emails, phone numbers, private notes, stages, next steps, and follow-up dates.
- Dated conversation history for sent messages, replies, calls, meetings, notes, and work started/completed. Incorrect entries can be removed from counts and restored.
- Searchable outreach views, due/overdue follow-ups, and people/activity CSV exports.
- Evidence-based website checks, a copyable overall summary, source links, suggested fixes, and printable reports.
- Save-first audit queue with duplicate protection, retries, and separate Google PageSpeed jobs.
- Editable campaign drafts, SEO content briefs, and a content library.
- Owner-scoped database records and authenticated write routes. Development and hosted data are separate.

## Counting rules

People contacted are unique contacts with a logged sent message or call. Replies count unique contacts with a logged reply; response rate uses replied contacts among those contacted. Repeated follow-ups do not inflate people counts. Draft campaigns do not count as sent. Websites won count unique linked websites with a client stage or work history; websites worked on count work started/completed or an in-progress/completed stage.

Activity logging is manual. This app does not sync an inbox, send emails, publish articles, or deliver background reminder notifications. Follow-up dates appear inside the workspace. AI article writing remains disabled. Audits resume while the workspace is open; fully unattended execution is not connected. PageSpeed is quota-dependent, and unavailable tests are reported honestly.

## Run locally

Use Node.js 22.13 or newer and npm. The project uses React, TypeScript, Vinext/Vite, and Cloudflare D1.

```sh
npm run install:ci
npm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_tense_black_bird.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_lively_blackheart.sql
npm run dev
```

Apply those migrations only to a fresh local database, once and in order. Open the printed localhost URL. If sign-in is needed, use the Sign in link to activate the loopback-only development identity. Production sign-in is supplied by Sites; the local mock identity is not included in production builds.

```sh
node --test tests/audit.test.mjs tests/persistence.test.mjs
npx tsc --noEmit
npm run build
```

## Hosting and sharing

Publishing uses the Sites workflow with a D1 binding named `DB` and server-side ChatGPT authentication. A source-code repository is not the running application. GitHub Pages cannot host its server routes or D1 database. To host another copy, register a new Site, configure its own project identity, and publish with the Sites plugin. Do not reuse another person's deployment identity.

The GitHub sharing copy omits the original deployment identity, research seed, screenshots, local database, user records, and runtime credentials. It starts with an empty workspace. The source-managed research import test is skipped in that copy when no seed is supplied; the other tests still run.

Keep `.env*`, `.dev.vars*`, `.wrangler/`, `.sites-runtime/`, and database exports out of Git. A dedicated PageSpeed key is optional and must be configured as a runtime secret. The HTML audit is a sample of up to three pages, not proof of full accessibility, visual design quality, search rankings, or conversions.
