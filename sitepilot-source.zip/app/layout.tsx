import type { Metadata } from "next";
import "./sitepilot.css";
import "./outreach.css";

export const metadata: Metadata = {
  title: "Sitepilot — My website & outreach workspace",
  description: "A personal workspace for website reviews, contacts, conversations, follow-ups, and SEO content briefs.",
  icons: {
    icon: "/sitepilot.svg",
    shortcut: "/sitepilot.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
