import {owner,errorResponse,sameOrigin} from "@/lib/store";
import {queueWebsites} from "@/lib/jobs";
// Compatibility route: save first, then let the durable queue perform the checks.
export async function POST(request:Request){try{sameOrigin(request);const who=await owner();const raw=await request.text();if(raw.length>8000)throw new Error("Input too large.");const input=JSON.parse(raw);return Response.json(await queueWebsites(who,{...input,urls:[input.url]}),{status:202});}catch(e){return errorResponse(e);}}
