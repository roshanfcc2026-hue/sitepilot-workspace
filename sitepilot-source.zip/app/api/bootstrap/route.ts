import {owner,sameOrigin,errorResponse} from "@/lib/store";
import {importResearch} from "@/lib/research-import";
export async function POST(request:Request){try{sameOrigin(request);return Response.json(await importResearch(await owner()));}catch(e){return errorResponse(e);}}
