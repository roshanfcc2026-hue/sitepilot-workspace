import {owner,get,put,errorResponse,sameOrigin} from "@/lib/store";
import {createCampaign,createBrief} from "@/lib/content";
import {defaultSettings,type Audit,type Settings} from "@/lib/types";
export async function POST(request:Request){try{sameOrigin(request);const who=await owner();const raw=await request.text();if(raw.length>5000)throw new Error("Input too large.");const input=JSON.parse(raw);const audit=await get<Audit>(who,input.auditId,"audit");if(!audit)throw new Error("Select a saved audit first.");const settings=await get<Settings>(who,`settings:${who}`,"settings")||defaultSettings;
 if(input.kind==="campaign"){const result=createCampaign(audit,settings);await put(who,"campaign",{...result});return Response.json(result);}
 if(input.kind!=="brief")throw new Error("Full AI article writing is paused. Create an SEO brief instead.");
 const article=createBrief(audit,String(input.keyword||"").slice(0,150));await put(who,"article",{...article});return Response.json(article);
}catch(e){return errorResponse(e);}}
